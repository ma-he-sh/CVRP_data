var data_3_23 = {
    "1": {
        "index": 1,
        "location": "Foleyet",
        "lat": 48.243889,
        "lng": -82.439722,
        "demand": 0.0,
        "cityref": 96
    },
    "2": {
        "index": 2,
        "location": "Fenwick",
        "lat": 43.0240705,
        "lng": -79.3622975,
        "demand": 9.0,
        "cityref": 60
    },
    "3": {
        "index": 3,
        "location": "Victoria",
        "lat": 44.596151,
        "lng": -78.939262,
        "demand": 296.0,
        "cityref": 161
    },
    "4": {
        "index": 4,
        "location": "Harrow",
        "lat": 42.0355591,
        "lng": -82.918148,
        "demand": 236.0,
        "cityref": 20
    },
    "5": {
        "index": 5,
        "location": "Cardiff",
        "lat": 44.995666299999996,
        "lng": -78.0147032,
        "demand": 101.0,
        "cityref": 139
    },
    "6": {
        "index": 6,
        "location": "Hanmer",
        "lat": 46.652064,
        "lng": -80.9463083,
        "demand": 250.0,
        "cityref": 243
    },
    "7": {
        "index": 7,
        "location": "Lafontaine",
        "lat": 44.75,
        "lng": -80.06666700000001,
        "demand": 11.0,
        "cityref": 91
    },
    "8": {
        "index": 8,
        "location": "Gananoque",
        "lat": 44.330618,
        "lng": -76.16186400000001,
        "demand": 8.0,
        "cityref": 220
    },
    "9": {
        "index": 9,
        "location": "Plattsville",
        "lat": 43.303253999999995,
        "lng": -80.62156999999998,
        "demand": 99.0,
        "cityref": 16
    },
    "10": {
        "index": 10,
        "location": "Savant Lake",
        "lat": 50.23748699999999,
        "lng": -90.7007,
        "demand": 22.0,
        "cityref": 148
    },
    "11": {
        "index": 11,
        "location": "Scotland",
        "lat": 43.025258799999996,
        "lng": -80.37516819999998,
        "demand": 56.0,
        "cityref": 90
    },
    "12": {
        "index": 12,
        "location": "Madoc",
        "lat": 44.5052295,
        "lng": -77.47263629999998,
        "demand": 172.0,
        "cityref": 135
    },
    "13": {
        "index": 13,
        "location": "Rolphton",
        "lat": 46.1666669,
        "lng": -77.7,
        "demand": 298.0,
        "cityref": 147
    },
    "14": {
        "index": 14,
        "location": "Mount Brydges",
        "lat": 42.9096845,
        "lng": -81.49586009999999,
        "demand": 43.0,
        "cityref": 207
    },
    "15": {
        "index": 15,
        "location": "Restoule",
        "lat": 46.02686,
        "lng": -79.719627,
        "demand": 173.0,
        "cityref": 36
    },
    "16": {
        "index": 16,
        "location": "Strathroy",
        "lat": 42.955420000000004,
        "lng": -81.62323330000002,
        "demand": 171.0,
        "cityref": 223
    },
    "17": {
        "index": 17,
        "location": "Casselman",
        "lat": 45.310704799999996,
        "lng": -75.0893653,
        "demand": 152.0,
        "cityref": 198
    },
    "18": {
        "index": 18,
        "location": "Iron Bridge",
        "lat": 46.278529999999996,
        "lng": -83.22259199999998,
        "demand": 278.0,
        "cityref": 162
    },
    "19": {
        "index": 19,
        "location": "Marmora",
        "lat": 44.482946999999996,
        "lng": -77.68210599999998,
        "demand": 10.0,
        "cityref": 127
    },
    "20": {
        "index": 20,
        "location": "Inverary",
        "lat": 44.388594,
        "lng": -76.47323399999998,
        "demand": 221.0,
        "cityref": 73
    },
    "21": {
        "index": 21,
        "location": "Colborne",
        "lat": 44.0050203,
        "lng": -77.88823040000003,
        "demand": 156.0,
        "cityref": 87
    },
    "22": {
        "index": 22,
        "location": "Hemlo",
        "lat": 48.683333000000005,
        "lng": -85.983333,
        "demand": 186.0,
        "cityref": 240
    },
    "23": {
        "index": 23,
        "location": "Belmont",
        "lat": 42.8813217,
        "lng": -81.08754119999998,
        "demand": 21.0,
        "cityref": 170
    }
}