var data_2_23 = {
    "1": {
        "index": 1,
        "location": "Port Dover",
        "lat": 42.7865225,
        "lng": -80.20327790000002,
        "demand": 0.0,
        "cityref": 39
    },
    "2": {
        "index": 2,
        "location": "Haileybury",
        "lat": 47.4463218,
        "lng": -79.6354588,
        "demand": 152.0,
        "cityref": 81
    },
    "3": {
        "index": 3,
        "location": "Douglastown",
        "lat": 42.974767,
        "lng": -79.025764,
        "demand": 126.0,
        "cityref": 50
    },
    "4": {
        "index": 4,
        "location": "Wainfleet",
        "lat": 42.923365999999994,
        "lng": -79.3757559,
        "demand": 51.0,
        "cityref": 63
    },
    "5": {
        "index": 5,
        "location": "Chatsworth",
        "lat": 44.37167120000001,
        "lng": -80.85438470000001,
        "demand": 86.0,
        "cityref": 47
    },
    "6": {
        "index": 6,
        "location": "Fingal",
        "lat": 42.712527,
        "lng": -81.310902,
        "demand": 54.0,
        "cityref": 83
    },
    "7": {
        "index": 7,
        "location": "North Bay",
        "lat": 46.3091152,
        "lng": -79.4608204,
        "demand": 211.0,
        "cityref": 34
    },
    "8": {
        "index": 8,
        "location": "Bradford West Gwillimbury",
        "lat": 44.114899,
        "lng": -79.56295290000001,
        "demand": 209.0,
        "cityref": 70
    },
    "9": {
        "index": 9,
        "location": "Utterson",
        "lat": 45.211059999999996,
        "lng": -79.32926499999998,
        "demand": 174.0,
        "cityref": 54
    },
    "10": {
        "index": 10,
        "location": "Seaforth",
        "lat": 43.5534346,
        "lng": -81.39340490000001,
        "demand": 27.0,
        "cityref": 78
    },
    "11": {
        "index": 11,
        "location": "Barry`s Bay",
        "lat": 45.4882068,
        "lng": -77.67880509999998,
        "demand": 1.0,
        "cityref": 51
    },
    "12": {
        "index": 12,
        "location": "Hagersville",
        "lat": 42.9598903,
        "lng": -80.05228609999999,
        "demand": 238.0,
        "cityref": 65
    },
    "13": {
        "index": 13,
        "location": "Tavistock",
        "lat": 43.2470056,
        "lng": -80.78794070000001,
        "demand": 203.0,
        "cityref": 46
    },
    "14": {
        "index": 14,
        "location": "Port Stanley",
        "lat": 42.66413529999999,
        "lng": -81.21563290000002,
        "demand": 126.0,
        "cityref": 1
    },
    "15": {
        "index": 15,
        "location": "Thessalon First Nation",
        "lat": 46.2451906,
        "lng": -83.41681640000002,
        "demand": 296.0,
        "cityref": 55
    },
    "16": {
        "index": 16,
        "location": "Mallorytown",
        "lat": 44.47933099999999,
        "lng": -75.884855,
        "demand": 37.0,
        "cityref": 2
    },
    "17": {
        "index": 17,
        "location": "Smiths Falls",
        "lat": 44.903748,
        "lng": -76.02161889999998,
        "demand": 57.0,
        "cityref": 85
    },
    "18": {
        "index": 18,
        "location": "Navan",
        "lat": 45.421034000000006,
        "lng": -75.4267251,
        "demand": 284.0,
        "cityref": 76
    },
    "19": {
        "index": 19,
        "location": "Alderville First Nation",
        "lat": 44.1728865,
        "lng": -78.0851607,
        "demand": 82.0,
        "cityref": 42
    },
    "20": {
        "index": 20,
        "location": "Killarney",
        "lat": 45.97191369999999,
        "lng": -81.51149720000001,
        "demand": 71.0,
        "cityref": 100
    },
    "21": {
        "index": 21,
        "location": "Foymount",
        "lat": 45.437767,
        "lng": -77.30616490000001,
        "demand": 87.0,
        "cityref": 37
    },
    "22": {
        "index": 22,
        "location": "Palmer Rapids",
        "lat": 45.316666999999995,
        "lng": -77.516667,
        "demand": 184.0,
        "cityref": 14
    },
    "23": {
        "index": 23,
        "location": "Whitby",
        "lat": 43.897544599999996,
        "lng": -78.94293290000002,
        "demand": 170.0,
        "cityref": 6
    }
}