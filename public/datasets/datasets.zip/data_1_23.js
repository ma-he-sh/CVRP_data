var data_1_23 = {
    "1": {
        "index": 1,
        "location": "Whitby",
        "lat": 43.897544599999996,
        "lng": -78.94293290000002,
        "demand": 0.0,
        "cityref": 7
    },
    "2": {
        "index": 2,
        "location": "Richmond Hill",
        "lat": 43.8828401,
        "lng": -79.4402808,
        "demand": 193.0,
        "cityref": 12
    },
    "3": {
        "index": 3,
        "location": "Uxbridge",
        "lat": 44.10940280000001,
        "lng": -79.12049979999998,
        "demand": 198.0,
        "cityref": 10
    },
    "4": {
        "index": 4,
        "location": "Halton Hills",
        "lat": 43.646987,
        "lng": -80.017663,
        "demand": 145.0,
        "cityref": 16
    },
    "5": {
        "index": 5,
        "location": "Newmarket",
        "lat": 44.05918700000001,
        "lng": -79.46125599999998,
        "demand": 171.0,
        "cityref": 22
    },
    "6": {
        "index": 6,
        "location": "Clarington",
        "lat": 43.9345347,
        "lng": -78.60003359999999,
        "demand": 81.0,
        "cityref": 6
    },
    "7": {
        "index": 7,
        "location": "Aurora",
        "lat": 44.006479999999996,
        "lng": -79.450396,
        "demand": 36.0,
        "cityref": 17
    },
    "8": {
        "index": 8,
        "location": "Georgina",
        "lat": 44.296296000000005,
        "lng": -79.43623199999998,
        "demand": 16.0,
        "cityref": 20
    },
    "9": {
        "index": 9,
        "location": "Caledon",
        "lat": 43.8363372,
        "lng": -79.87448359999998,
        "demand": 139.0,
        "cityref": 23
    },
    "10": {
        "index": 10,
        "location": "Oakville",
        "lat": 43.467517,
        "lng": -79.68766590000001,
        "demand": 1.0,
        "cityref": 11
    },
    "11": {
        "index": 11,
        "location": "Oshawa",
        "lat": 43.8970929,
        "lng": -78.86579119999998,
        "demand": 96.0,
        "cityref": 19
    },
    "12": {
        "index": 12,
        "location": "Ajax",
        "lat": 43.85085529999999,
        "lng": -79.02037320000001,
        "demand": 121.0,
        "cityref": 13
    },
    "13": {
        "index": 13,
        "location": "East Gwillimbury",
        "lat": 44.1010645,
        "lng": -79.4417811,
        "demand": 39.0,
        "cityref": 1
    },
    "14": {
        "index": 14,
        "location": "Milton",
        "lat": 43.51829910000001,
        "lng": -79.8774042,
        "demand": 146.0,
        "cityref": 18
    },
    "15": {
        "index": 15,
        "location": "Mississauga",
        "lat": 43.58904520000001,
        "lng": -79.6441198,
        "demand": 278.0,
        "cityref": 3
    },
    "16": {
        "index": 16,
        "location": "Pickering",
        "lat": 43.83841169999999,
        "lng": -79.08675790000001,
        "demand": 59.0,
        "cityref": 4
    },
    "17": {
        "index": 17,
        "location": "Vaughan",
        "lat": 43.8563158,
        "lng": -79.5085383,
        "demand": 101.0,
        "cityref": 21
    },
    "18": {
        "index": 18,
        "location": "Brampton",
        "lat": 43.7315479,
        "lng": -79.7624177,
        "demand": 171.0,
        "cityref": 14
    },
    "19": {
        "index": 19,
        "location": "Kingston",
        "lat": 44.2311717,
        "lng": -76.48595440000001,
        "demand": 126.0,
        "cityref": 5
    },
    "20": {
        "index": 20,
        "location": "Brock",
        "lat": 44.33756899999999,
        "lng": -79.09541,
        "demand": 267.0,
        "cityref": 8
    },
    "21": {
        "index": 21,
        "location": "Markham",
        "lat": 43.8561002,
        "lng": -79.3370188,
        "demand": 192.0,
        "cityref": 9
    },
    "22": {
        "index": 22,
        "location": "Burlington",
        "lat": 43.3255196,
        "lng": -79.7990319,
        "demand": 90.0,
        "cityref": 15
    },
    "23": {
        "index": 23,
        "location": "Toronto",
        "lat": 43.653226000000004,
        "lng": -79.3831843,
        "demand": 154.0,
        "cityref": 2
    }
}